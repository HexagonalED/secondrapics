/* -*- mode: c -*- */
#include <GL/glut.h>
#include "curve.h"

/* global */
CubicBezierCurve curve;
GLsizei width = 640, height = 480;
int edit_ctrlpts_idx = -1;

int hit_index(CubicBezierCurve *curve, int x, int y)
{
    int i;
    for (i=0; i<4; ++i) {
        REAL tx = curve->control_pts[i][0] - x;
        REAL ty = curve->control_pts[i][1] - y;
        if ((tx * tx + ty * ty) < 30)
            return i;
    }
    return -1;
}

void init()
{
    SET_PT2(curve.control_pts[0], 50, 100);
    SET_PT2(curve.control_pts[1], 200, 300);
    SET_PT2(curve.control_pts[2], 400, 300);
    SET_PT2(curve.control_pts[3], 550, 100);

    glClearColor(1.0, 1.0, 1.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0, width, 0, height);
}

void reshape_callback(GLint nw, GLint nh)
{
    width = nw;
    height = nh;
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, width, 0, height);
}

void display_callback(void)
{
#define RES 100
    int i;

    /* curve */
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3ub(0, 0, 0);
    glBegin(GL_LINE_STRIP);
    for (i=0; i<=RES; ++i) {
        Point pt;
        const REAL t = (REAL)i / (REAL)RES;
        evaluate(&curve, t, pt);
        glVertex2f(pt[0], pt[1]);
    }
    glEnd();

    /* control mesh */
    glColor3ub(255, 0, 0);
    glBegin(GL_LINE_STRIP);
    for (i=0; i<4; ++i) {
        REAL *pt = curve.control_pts[i];
        glVertex2f(pt[0], pt[1]);
    }
    glEnd();

    /* control pts */
    glColor3ub(0, 0, 255);
    glPointSize(10.0);
    glBegin(GL_POINTS);
    for (i=0; i<4; ++i) {
        REAL *pt = curve.control_pts[i];
        glVertex2f(pt[0], pt[1]);
    }
    glEnd();
    glutSwapBuffers();
}

void mouse_callback(GLint button, GLint action, GLint x, GLint y)
{
    if (GLUT_LEFT_BUTTON == button) {
        switch (action) {
            case GLUT_DOWN:
                edit_ctrlpts_idx = hit_index(&curve, x, height - y);
                break;

            case GLUT_UP:
                edit_ctrlpts_idx = -1;
                break;
        }
    }
    glutSwapBuffers();
}

void mouse_move_callback(GLint x, GLint y)
{
    if (edit_ctrlpts_idx != -1) {
        curve.control_pts[edit_ctrlpts_idx][0] = (REAL)x;
		curve.control_pts[edit_ctrlpts_idx][1] = (REAL)(height - y);
    }
    glutPostRedisplay();
}

int main(int argc, char *argv[])
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(width, height);
    glutCreateWindow("Bezier Editor");

    init();
    glutReshapeFunc(reshape_callback);
    glutMouseFunc(mouse_callback);
    glutMotionFunc(mouse_move_callback);
    glutDisplayFunc(display_callback);
    glutMainLoop();
    return 0;
}
